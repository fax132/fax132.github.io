import { system, world, ItemStack } from "@minecraft/server";

//food list
function isFood(itemType) {
    const allowedFoods = [
        "minecraft:apple",
        "minecraft:milk_bucket",
        "minecraft:honey_bottle",
        "minecraft:baked_potato",
        "minecraft:potato",
        "minecraft:beetroot",
        "minecraft:beetroot_soup",
        "minecraft:bread",
        "minecraft:cake",
        "minecraft:carrot",
        "minecraft:cooked_beef",
        "minecraft:cooked_chicken",
        "minecraft:cooked_cod",
        "minecraft:cooked_mutton",
        "minecraft:cooked_porkchop",
        "minecraft:cooked_rabbit",
        "minecraft:cooked_salmon",
        "minecraft:cookie",
        "minecraft:dried_kelp",
        "minecraft:enchanted_golden_apple",
        "minecraft:golden_apple",
        "minecraft:golden_carrot",
        "minecraft:melon_slice",
        "minecraft:melon_block",
        "minecraft:mushroom_stew",
        "minecraft:porkchop",
        "minecraft:rabbit_stew",
        "minecraft:beef",
        "minecraft:chicken",
        "minecraft:cod",
        "minecraft:mutton",
        "minecraft:porkchop",
        "minecraft:rabbit",
        "minecraft:salmon",
        "minecraft:sweet_berries",
        "minecraft:glow_berries",
        "minecraft:suspicious_stew",
        "minecraft:chorus_fruit",
        "minecraft:pumpkin_pie",
        "dds_camping:marshmallow",
        "dds_camping:cooked_marshmallow",
        "dds_camping:bobcat_meat",
        "dds_camping:bobcat_meat_cooked"
    ];       
    return allowedFoods.includes(itemType);
}

function createRandomStringId(length = 8) {
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    let result = "";
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

function hideLoreString(unhiddenString) {
    return unhiddenString.split('').map(char => `§${char}`).join('');
}

function unhideLoreString(hiddenString) {
    return hiddenString.split('').filter((char, index) => index % 2 === 1).join('');
}

world.beforeEvents.itemUseOn.subscribe(event => {
    const player = event.source;
    const blockHit = player.getBlockFromViewDirection().block;
    const itemStack = event.itemStack;
    const itemLore = itemStack.getLore();
    let backpackId = itemLore.length > 0 ? unhideLoreString(itemLore[0]).split("_")[1] : null;

    if (player.hasTag("dds_camping_hamper_target") && itemStack.typeId === "dds_camping:hamper_spawn_egg") {
        if (player.hasTag("dds_camping_hamper_cooldown")) {
            return;
        }
        event.cancel = true;

        if (!backpackId) {
            backpackId = createRandomStringId(8);
            system.run(() => {
                itemStack.setLore([hideLoreString(`bag_${backpackId}`)]);
            });
            system.run(() => {
                const bagLocation = {
                    x: blockHit.location.x + 0.5,
                    y: blockHit.location.y + 1,
                    z: blockHit.location.z + 0.5
                };
                const playerName = `dds_money_hamper`;
                player.runCommand(`clear @s dds_camping:hamper_spawn_egg -1 1`);
                player.dimension.spawnEntity("dds_camping:hamper", bagLocation);
                system.runTimeout(() => {
                    player.removeTag("dds_camping_hamper_cooldown");
                }, 20);
            });
        } else {
            system.run(() => {
                const playerName = `dds_money_hamper`;
                player.runCommand(`clear @s dds_camping:hamper_spawn_egg -1 1`);
                player.runCommand(`structure load ${playerName}_${backpackId} ${blockHit.location.x} ${blockHit.location.y + 1} ${blockHit.location.z}`);
                system.runTimeout(() => {
                    player.removeTag("dds_camping_hamper_cooldown");
                }, 20);
            });
        }
    }
});

world.afterEvents.entityHitEntity.subscribe(data => {
    const hitEntity = data.hitEntity;
    const attacker = data.damagingEntity;
	if (hitEntity.typeId !== "dds_camping:hamper" || attacker.typeId !== "minecraft:player" || !attacker.isSneaking) {
        return;
    }
	const entityBlockLocation = {
      x: Math.floor(hitEntity.location.x),
      y: Math.floor(hitEntity.location.y),
      z: Math.floor(hitEntity.location.z)
    };
    if (hitEntity.typeId === "dds_camping:hamper" && attacker.typeId === "minecraft:player" && attacker.isSneaking) {
        const dynamicProperties = hitEntity.getDynamicProperty("backpackId");
        let backpackId = dynamicProperties?.backpackId ?? createRandomStringId(8);

        if (!dynamicProperties?.backpackId) {
            hitEntity.setDynamicProperty("backpackId", backpackId);
        }

        hitEntity.addEffect("regeneration", 99999, { amplifier: 8.9, showParticles: false });
        attacker.addTag("dds_camping_hamper_target");
        hitEntity.runCommand(`structure save dds_money_hamper_${backpackId} ${entityBlockLocation.x} ${entityBlockLocation.y} ${entityBlockLocation.z} ${entityBlockLocation.x} ${entityBlockLocation.y} ${entityBlockLocation.z} true disk true`);

        const itemStack = new ItemStack("dds_camping:hamper_spawn_egg", 1);
        itemStack.setLore([hideLoreString(`bag_${backpackId}`)]);

        hitEntity.dimension.spawnItem(itemStack, hitEntity.location);
        hitEntity.runCommand(`fill ~~-1~ ~~1~ air [] replace minecraft:barrier`);
        hitEntity.remove();
    }
}, { entityTypes: ['minecraft:player'] });

// Check hamper inventories periodically
system.runInterval(() => {
    for (const player of world.getPlayers()) {
        const dimension = player.dimension;
        const hampers = dimension.getEntities({
            type: "dds_camping:hamper",
            location: player.location,
            radius: 5,
        });

        for (const hamper of hampers) {
            const inventory = hamper.getComponent("minecraft:inventory");
            if (inventory) {
                const container = inventory.container;
                const hamperlocation = {
                    x: hamper.location.x,
                    y: hamper.location.y + 1,
                    z: hamper.location.z
                };
                for (let slot = 0; slot < container.size; slot++) {
                    const itemStack = container.getItem(slot);
                    if (itemStack && !isFood(itemStack.typeId)) {
                        container.setItem(slot, null);
                        hamper.dimension.spawnItem(itemStack, hamperlocation);
                        // player.getComponent("minecraft:inventory").container.addItem(itemStack);
                        player.runCommand(`titleraw @a[r=5] actionbar {"rawtext":[{"text":"§cOnly food can be stored!"}]}`);
                    }
                }
            }
        }
    }
}, 20);

//system for tent
world.beforeEvents.itemUseOn.subscribe(event => {
    const player = event.source;
    const blockHit = player.getBlockFromViewDirection().block;
    const itemStack = event.itemStack;
    const itemLore = itemStack.getLore();
    let backpackId = itemLore.length > 0 ? unhideLoreString(itemLore[0]).split("_")[1] : null;

    if (player.hasTag("dds_camping_tent_target") && itemStack.typeId === "dds_camping:tent_spawn_egg") {
        if (player.hasTag("dds_camping_tent_cooldown")) {
            return;
        }
        event.cancel = true;

        if (!backpackId) {
            backpackId = createRandomStringId(8);
            system.run(() => {
                itemStack.setLore([hideLoreString(`bag_${backpackId}`)]);
            });
            system.run(() => {
                const bagLocation = {
                    x: blockHit.location.x + 0.5,
                    y: blockHit.location.y + 1,
                    z: blockHit.location.z + 0.5
                };
                const playerName = `dds_camping_tent`;
                player.runCommand(`clear @s dds_camping:tent_spawn_egg -1 1`);
                player.dimension.spawnEntity("dds_camping:tent", bagLocation);
                system.runTimeout(() => {
                    player.removeTag("dds_camping_tent_cooldown");
                }, 20);
            });
        } else {
            system.run(() => {
                const playerName = `dds_camping_tent`;
                player.runCommand(`clear @s dds_camping:tent_spawn_egg -1 1`);
                player.runCommand(`structure load ${playerName}_${backpackId} ${blockHit.location.x} ${blockHit.location.y + 1} ${blockHit.location.z}`);
                system.runTimeout(() => {
                    player.removeTag("dds_camping_tent_cooldown");
                }, 20);
            });
        }
    }
});

world.afterEvents.entityHitEntity.subscribe(data => {
    const hitEntity = data.hitEntity;
    const attacker = data.damagingEntity;
	if (hitEntity.typeId !== "dds_camping:tent" || attacker.typeId !== "minecraft:player" || !attacker.isSneaking) {
        return;
    }
	const entityBlockLocation = {
      x: Math.floor(hitEntity.location.x),
      y: Math.floor(hitEntity.location.y),
      z: Math.floor(hitEntity.location.z)
    };
    if (hitEntity.typeId === "dds_camping:tent" && attacker.typeId === "minecraft:player" && attacker.isSneaking) {
        const dynamicProperties = hitEntity.getDynamicProperty("backpackId");
        let backpackId = dynamicProperties?.backpackId ?? createRandomStringId(8);

        if (!dynamicProperties?.backpackId) {
            hitEntity.setDynamicProperty("backpackId", backpackId);
        }

        hitEntity.addEffect("regeneration", 99999, { amplifier: 8.9, showParticles: false });
        attacker.addTag("dds_camping_tent_target");
        hitEntity.runCommand(`structure save dds_camping_tent_${backpackId} ${entityBlockLocation.x} ${entityBlockLocation.y} ${entityBlockLocation.z} ${entityBlockLocation.x} ${entityBlockLocation.y} ${entityBlockLocation.z} true disk true`);

        const itemStack = new ItemStack("dds_camping:tent_spawn_egg", 1);
        itemStack.setLore([hideLoreString(`bag_${backpackId}`)]);

        hitEntity.dimension.spawnItem(itemStack, hitEntity.location);
        hitEntity.runCommand(`fill ~~-1~ ~~1~ air [] replace minecraft:barrier`);
        hitEntity.remove();
    }
}, { entityTypes: ['minecraft:player'] });

//summoning sleepingbed in a given orientation
world.beforeEvents.itemUseOn.subscribe(event => {
    const player = event.source;
    const blockHit = player.getBlockFromViewDirection().block;
    const {x,y,z} = blockHit.location
    if (event.itemStack.typeId === "dds_camping:sleepingbag_spawn_egg") {
        event.cancel = true;
        system.run(() => {
            player.runCommand(`clear @s dds_camping:sleepingbag_spawn_egg 0 1`);
            player.runCommand(`summon dds_camping:sleepingbag ${x} ${y+1} ${z} 90 0`);
        });
    }
});