import { world, system, ItemStack } from '@minecraft/server';

const woodAndLeaves = {
    'minecraft:oak_log': 'minecraft:oak_leaves',
    'minecraft:spruce_log': 'minecraft:spruce_leaves',
    'minecraft:birch_log': 'minecraft:birch_leaves',
    'minecraft:jungle_log': 'minecraft:jungle_leaves',
    'minecraft:acacia_log': 'minecraft:acacia_leaves',
    'minecraft:dark_oak_log': 'minecraft:dark_oak_leaves',
    'minecraft:mangrove_log': 'minecraft:mangrove_leaves',
    'minecraft:cherry_log': 'minecraft:cherry_leaves',
    'minecraft:crimson_stem': 'minecraft:crimson_roots',
    'minecraft:warped_stem': 'minecraft:warped_roots'
};

world.beforeEvents.playerBreakBlock.subscribe(e => {
    const { block, itemStack, player } = e;
    const blockType = block.typeId;
    const correspondingLeaf = woodAndLeaves[blockType];

    const playerEquipped = player.getComponent("equippable");
    if (!playerEquipped) return;
    const UsedItemDurability = itemStack?.getComponent("durability");
    if (!UsedItemDurability) return;

    let dimension = block.dimension;

    const breakBlock = (location) => {
        let currentBlock = dimension.getBlock(location);
        if (currentBlock) {
            system.run(() => {
                dimension.runCommand(`setblock ${location.x} ${location.y} ${location.z} air destroy`);
            });
        }
    };

    if (correspondingLeaf) {
        if (blockType in woodAndLeaves) {
            let toBreak = [block.location];
            let checked = new Set();
            let brokenCount = 0;

            while (toBreak.length > 0 && brokenCount < 700) {
                let location = toBreak.shift();
                let key = `${location.x},${location.y},${location.z}`;
                if (checked.has(key)) continue;
                checked.add(key);

                let currentBlock = dimension.getBlock(location);
                if (currentBlock && (currentBlock.typeId === blockType || currentBlock.typeId === correspondingLeaf)) {
                    breakBlock(location);
                    brokenCount++;

                    let adjacent = [
                        { x: location.x + 1, y: location.y, z: location.z },
                        { x: location.x - 1, y: location.y, z: location.z },
                        { x: location.x, y: location.y + 1, z: location.z },
                        { x: location.x, y: location.y - 1, z: location.z },
                        { x: location.x, y: location.y, z: location.z + 1 },
                        { x: location.x, y: location.y, z: location.z - 1 }
                    ];
                    for (let loc of adjacent) {
                        toBreak.push(loc);
                    }
                }
            }
        }
    } else {
        for (let [logType, leafType] of Object.entries(woodAndLeaves)) {
            if (blockType === leafType) {
                let toCheck = [
                    { x: block.location.x + 1, y: block.location.y, z: block.location.z },
                    { x: block.location.x - 1, y: block.location.y, z: block.location.z },
                    { x: block.location.x, y: block.location.y + 1, z: block.location.z },
                    { x: block.location.x, y: block.location.y - 1, z: block.location.z },
                    { x: block.location.x, y: block.location.y, z: block.location.z + 1 },
                    { x: block.location.x, y: block.location.y, z: block.location.z - 1 }
                ];
                
                for (let loc of toCheck) {
                    let adjacentBlock = dimension.getBlock(loc);
                    if (adjacentBlock && adjacentBlock.typeId === logType) {
                        breakBlock(loc);
                    }
                }
            }
        }
    }

    system.run(() => {
        UsedItemDurability.damage += 1;

        const maxDurability = UsedItemDurability.maxDurability;
        const currentDamage = UsedItemDurability.damage;
        if (currentDamage >= maxDurability) {
            player.playSound('random.break', { pitch: 1, location: player.location, volume: 1 });
            playerEquipped.setEquipment("Mainhand", new ItemStack('minecraft:air', 1));
        } else {
            playerEquipped.setEquipment("Mainhand", itemStack);
        }
    });
});
