import { world, system, EquipmentSlot, EntityEquippableComponent, BlockPermutation } from "@minecraft/server";

const lightBlockType = "minecraft:light_block";
const lightLevel = 14;

const replaceables = new Set([
    'minecraft:air',
    'minecraft:water',
    'minecraft:flowing_water',
]);

let activeLight = new Map();

system.runInterval(() => {
    world.getPlayers().forEach(player => {
        let equipmentComponent = player.getComponent(EntityEquippableComponent.componentId);
        let mainHandItem = equipmentComponent.getEquipment(EquipmentSlot.Mainhand);
        
        let headPosition = { 
            x: Math.floor(player.location.x), 
            y: Math.floor(player.location.y + 1.5), // head location
            z: Math.floor(player.location.z)
        };
        let feetPosition = { 
            x: Math.floor(player.location.x), 
            y: Math.floor(player.location.y), // Feet location
            z: Math.floor(player.location.z)
        };
        
        let lightData = activeLight.get(player.id);

        if (mainHandItem && mainHandItem.typeId === "dds_camping:camping_lantern") {
            if (!lightData) {
                placeLightBlock(player, headPosition, feetPosition);
            } else if (!positionsEqual(lightData.position, headPosition) && !positionsEqual(lightData.position, feetPosition)) {
                player.runCommand("function dds/camping/replacing_light");
                placeLightBlock(player, headPosition, feetPosition);
            }
        } else if (lightData) {
            player.runCommand("function dds/camping/replacing_light");
            activeLight.delete(player.id);
        }
    });
}, 5);

function placeLightBlock(player, headPosition, feetPosition) {
    let dimension = player.dimension;

    let headBlock = dimension.getBlock(headPosition);
    if (headBlock && replaceables.has(headBlock.typeId)) {
        headBlock.setPermutation(BlockPermutation.resolve(lightBlockType, { block_light_level: lightLevel }));
        activeLight.set(player.id, { position: headPosition, dimension });
    } else {
        let feetBlock = dimension.getBlock(feetPosition);
        if (feetBlock && replaceables.has(feetBlock.typeId)) {
            feetBlock.setPermutation(BlockPermutation.resolve(lightBlockType, { block_light_level: lightLevel }));
            activeLight.set(player.id, { position: feetPosition, dimension });
        }
    }
}

function positionsEqual(pos1, pos2) {
    return pos1.x === pos2.x && pos1.y === pos2.y && pos1.z === pos2.z;
}