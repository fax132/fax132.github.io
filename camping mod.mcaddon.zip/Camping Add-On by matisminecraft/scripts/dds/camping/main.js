import { system, world, ItemStack, Direction } from "@minecraft/server";
import "./utility/hamper.js";
import "./utility/capatitor.js";
import "./utility/dy_light.js";

//giving players the book upon joining world
world.afterEvents.playerSpawn.subscribe(async ({ player, initialSpawn }) => {
    if (!initialSpawn) return
    if (!player.hasTag("dds_camping_guide_1")) {
        player.runCommand(`structure load "dds_camping/guidebook" ~ ~ ~`);
        player.addTag("dds_camping_guide_1");
    }
});

// System for binocular
// When player starts using the item
world.afterEvents.itemStartUse.subscribe((event) => {
    const itemStack = event.itemStack;
    if (itemStack && itemStack.typeId === "dds_camping:binocular") {
        const player = event.source;
        player.addEffect("slowness", 99999, { amplifier: 8.9, showParticles: false });
        player.playSound("item.spyglass.use", { volume: 0.3 });
    }
});

// When player stops using the item
world.afterEvents.itemStopUse.subscribe((event) => {
    const itemStack = event.itemStack;
    if (itemStack && itemStack.typeId === "dds_camping:binocular") {
        const player = event.source;
        player.removeEffect('slowness');
        player.playSound("item.spyglass.stop_using", { volume: 0.3 });
    }
});

//grappling hook system
world.afterEvents.itemUse.subscribe(event => {
    const player = event.source;
    const item = event.itemStack;
    const view = player.getViewDirection();
    let velocity = { x: view.x * 2, y: view.y * 2, z: view.z * 2 };

    if (item.typeId === 'dds_camping:grappling_hook' && item.getComponent("minecraft:cooldown").getCooldownTicksRemaining(player) > 34) {
        player.runCommand(`event entity @e[type=dds_camping:hook_projectile,tag="${player.id}"] dds_camping:despawn`);
        let arrowEntity = player.dimension.spawnEntity("dds_camping:hook_projectile", player.getHeadLocation());
        let arrowProjectileComp = arrowEntity?.getComponent('minecraft:projectile');
        arrowProjectileComp.shoot(velocity);
        arrowEntity.addTag(player.id);
        const leashable = arrowEntity.getComponent("leashable");
        leashable.leashTo(player);
    }
});

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const equippable = player.getComponent("minecraft:equippable");
        const mainhandEquipment = equippable.getEquipment('Mainhand');
        if (player.isJumping && mainhandEquipment && mainhandEquipment.typeId === "dds_camping:grappling_hook") {
            const hook = gethook(player);
            if (hook) {
                const x = Math.floor(hook.location.x);
                const y = Math.floor(hook.location.y);
                const z = Math.floor(hook.location.z);
                player.runCommand(`event entity @e[type=dds_camping:hook_projectile,tag="${player.id}",r=0.8] dds_camping:despawn`);
                player.runCommand(`tp @e[type=dds_camping:hook_projectile,tag="${player.id}"] ${x} ${y} ${z} facing @s`);
                try {
                    player.applyKnockback(hook.getViewDirection().x, hook.getViewDirection().z, Math.sqrt(hook.getViewDirection().x ** 2 + hook.getViewDirection().z ** 2) * -0.7, (hook.getViewDirection().y - 0.1) * -0.4);
                } catch (e) { }
                player.addEffect("slow_falling", 5, { amplifier: 3, showParticles: false });
            }
        } else if (player.isSneaking && mainhandEquipment && mainhandEquipment.typeId === "dds_camping:grappling_hook") {
            player.runCommand(`event entity @e[type=dds_camping:hook_projectile,tag="${player.id}"] dds_camping:despawn`);
        }
    }
}, 1);

world.afterEvents.projectileHitBlock.subscribe((eventData) => {
    const projectile = eventData.projectile;
    const owner = eventData.source;

    if (projectile.typeId === "dds_camping:hook_projectile" && owner) {
        projectile.addTag(owner.id);
    }
});

world.afterEvents.entityDie.subscribe((event) => {
    const entity = event.deadEntity;
    if (entity.typeId === 'minecraft:player') {
        entity.runCommand(`event entity @e[type=dds_camping:hook_projectile,tag="${entity.id}"] dds_camping:despawn`);
    }
});

function gethook(player) {
    for (const entity of player.dimension.getEntities()) {
        if (entity.typeId === "dds_camping:hook_projectile" && entity.hasTag(player.id)) {
            return entity;
        }
    }
    return null;
}

//particle for campfire
system.runInterval(() => {
    for (const player of world.getPlayers()) {
        const dimension = player.dimension;
        const campfires = dimension.getEntities({
            type: "dds_camping:campfire",
            location: player.location,
            radius: 20,
        });

        for (const campfire of campfires) {
            const sheared = campfire.getComponent("minecraft:is_sheared");
            const variant = campfire.getComponent("minecraft:variant");
            if (sheared && variant.value != 5) {
                campfire.runCommand(`particle dds_camping:campfire_smoke_particle ~ ~2 ~`);
            }
        }
    }
}, 10);

// Changing lamp
world.beforeEvents.itemUseOn.subscribe(event => {
    const player = event.source;
    const blockHitResult = player.getBlockFromViewDirection();
    const itemStack = event.itemStack;

    if (!blockHitResult || !blockHitResult.block) return;

    const blockHit = blockHitResult.block;
    const { x, y, z } = blockHit.location;
    const blockPairs = {
        "dds_camping:camping_lantern": "dds_camping:camping_lantern_off",
        "dds_camping:camping_lantern_off": "dds_camping:camping_lantern"
    };

    const itemsSet = new Set([
        "minecraft:fire_charge",
        "minecraft:flint_and_steel",
        "minecraft:blaze_rod",
    ]);

    const targetBlockType = blockHit.typeId;
    if (itemsSet.has(itemStack.typeId) && blockPairs[targetBlockType]) {
        const currentDirection = blockHit.permutation.getState("minecraft:cardinal_direction");
        const newBlockCommand = `setblock ${x} ${y} ${z} ${blockPairs[targetBlockType]}["minecraft:cardinal_direction"="${currentDirection}"]`;
        system.run(() => {
            player.runCommand(newBlockCommand);
        });
        event.cancel = true;
    }
});

//marshmallow effect
function secondsToTicks(seconds) {
    return seconds * 20;
}

const foodEffects = [
    {
        itemTypeId: "dds_camping:marshmallow",
        effectName: "jump_boost",
        effectAmplifier: 2,
        effectDurationTime: 10
    },
    {
        itemTypeId: "dds_camping:cooked_marshmallow",
        effectName: "speed",
        effectAmplifier: 2,
        effectDurationTime: 10
    }
];

world.afterEvents.itemCompleteUse.subscribe(({ source: player, itemStack: item }) => {
    const effect = foodEffects.find(effect => effect.itemTypeId === item.typeId);
    if (effect) {
        player.addEffect(effect.effectName, secondsToTicks(effect.effectDurationTime), { amplifier: effect.effectAmplifier, showParticles: false });
    } else {
        // console.warn(`No effect found for item type: ${item.typeId}`);
    }
});

//Skinning pumpkin
const directions = [Direction.South, Direction.West, Direction.North, Direction.East];

function getDirection(player) {
    let yRotation = player.getRotation().y;
    if (yRotation < 0) yRotation += 360; // Convert to positive if negative

    let cardinalRotation = Math.round(yRotation / 90);
    if (cardinalRotation === 4) cardinalRotation = 0; // 0 and 360 are the same rotation

    let currentDirection = directions[cardinalRotation];
    let oppositeDirection = directions[(cardinalRotation + 2) % 4]; // Opposite direction

    return {
        currentDirection: currentDirection,
        oppositeDirection: oppositeDirection
    };
}

world.beforeEvents.itemUseOn.subscribe((event) => {
    const player = event.source;
    const block = event.block;
    const { x, y, z } = block.location;
    const item = event.itemStack;
    const direction = getDirection(player);

    system.run(() => {
        const pumpkinBlock = player.dimension.getBlock(block);
        if (pumpkinBlock?.typeId === "minecraft:pumpkin" && item.typeId === "dds_camping:chainsaw") {
            const newBlockCommand = `setblock ${x} ${y} ${z} carved_pumpkin ["minecraft:cardinal_direction"="${direction.oppositeDirection.toLowerCase()}"]`;
            player.runCommand(newBlockCommand);
            player.playSound('pumpkin.carve', { pitch: 1, location: player.location, volume: 1 });
            const spawnLocation = {
                x: pumpkinBlock.location.x,
                y: pumpkinBlock.location.y + 0.8,
                z: pumpkinBlock.location.z
            };
            const itemStack = new ItemStack("minecraft:pumpkin_seeds", 1);
            player.dimension.spawnItem(itemStack, spawnLocation);
        }
    });
});

//test block pos change
const entityTypesToMonitor = new Set([
    "dds_camping:hamper",
    "dds_camping:campfire",
    "dds_camping:sleepingbag",
    "dds_camping:portable_stove"
]);

let initialPositions = {};

system.runInterval(() => {
    entityTypesToMonitor.forEach(entityType => {
        const entities = world.getDimension("overworld").getEntities({ type: entityType });

        entities.forEach(entity => {
            const entityId = entity.id;
            const currentPosition = entity.location;

            if (!initialPositions[entityId]) {
                initialPositions[entityId] = { ...currentPosition };
            } else {
                const initialPosition = initialPositions[entityId];
                const deltaX = Math.abs(initialPosition.x - currentPosition.x);
                const deltaY = Math.abs(initialPosition.y - currentPosition.y);
                const deltaZ = Math.abs(initialPosition.z - currentPosition.z);

                if (deltaX > 0.01 || deltaY > 0.01 || deltaZ > 0.01) {
                    entity.teleport(initialPosition);
                }
            }
        });
    });
}, 1);